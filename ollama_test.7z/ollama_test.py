from ollama import chat
from ollama import ChatResponse
while True:
    content=input('You:')
    response: ChatResponse = chat(model='gemma2', messages=[
     {
        'role': 'user',
        'content': content
     },
    ])
    #print(response['message']['content'])

    print(response.message.content)

